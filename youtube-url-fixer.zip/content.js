(function() {
    'use strict';

    function getModifiedURL() {
        const url = window.location.href;
        const searchStr = "youtube.com/watch?";

        if (url.includes(searchStr)) {
            const cleanPart = url.substring(url.indexOf(searchStr));
            return "https://www." + cleanPart.replace("youtube.com", "yout-ube.com");
        }
        return null;
    }

    function createButton() {
        // Só cria o botão se estiver de fato em um vídeo
        if (!window.location.href.includes("youtube.com/watch?")) {
            const oldBtn = document.getElementById('yt-to-yout-ube-btn');
            if (oldBtn) oldBtn.remove();
            return;
        }

        // Se o botão já existe, não faz nada
        if (document.getElementById('yt-to-yout-ube-btn')) return;

        const btn = document.createElement('button');
        btn.id = 'yt-to-yout-ube-btn';
        btn.textContent = '✨ Ir para Yout-ube';

        btn.style.cssText = `
            position: fixed;
            top: 70px;
            right: 20px;
            z-index: 99999;
            padding: 12px 18px;
            background-color: #f00;
            color: #fff;
            border: 2px solid #fff;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            font-family: Roboto, Arial, sans-serif;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.5);
            transition: transform 0.2s, background-color 0.2s;
        `;

        btn.onmouseover = () => btn.style.backgroundColor = '#cc0000';
        btn.onmouseout = () => btn.style.backgroundColor = '#f00';

        btn.onclick = function() {
            const newURL = getModifiedURL();
            if (newURL) window.location.href = newURL;
        };

        // Garante que o body existe antes de colocar o botão
        if (document.body) {
            document.body.appendChild(btn);
        }
    }

    function cleanCurrentAddress() {
        const url = window.location.href;
        const ytPrefix = "https://www.youtube.com/watch?";

        if (url.includes(ytPrefix) && !url.startsWith(ytPrefix)) {
            const cleanURL = url.substring(url.indexOf(ytPrefix));
            window.history.replaceState(null, '', cleanURL);
        }
    }

    function checkAndInit() {
        createButton();
        cleanCurrentAddress();
    }

    // Fica checando a cada 500ms caso o YouTube mude de página internamente
    setInterval(checkAndInit, 500);

    // Monitoramento nativo de mudanças de elementos na página
    document.addEventListener("DOMContentLoaded", () => {
        checkAndInit();
        const observer = new MutationObserver(checkAndInit);
        observer.observe(document.body, { subtree: true, childList: true });
    });

})();